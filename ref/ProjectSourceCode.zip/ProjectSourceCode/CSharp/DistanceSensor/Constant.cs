﻿
namespace DistanceSensor
{
    public class Constant
    {

        public static string EncodingFormat = "GB18030"; //"GB2312";
        public const string SOFTWAREVERSION = "1.0";

    }
}
